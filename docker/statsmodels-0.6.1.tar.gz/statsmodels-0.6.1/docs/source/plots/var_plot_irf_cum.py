from var_plots import plot_irf_cum
plot_irf_cum()
