from var_plots import plot_input
plot_input()
